var m = 2;
var n = Math.floor(Math.random() * m + 1);
switch (n) {
case 1:
document.writeln("<a href=\'https://178.pfwbpqpa.xyz/aff-a29tA\' target=\'_blank\'><img src=\'https://sc.561290.xyz/sc/cao300.gif\' width=\"300\" height=\"300\" ></a>");
break;
case 2:
document.writeln("<a href=\'https://5fb5.pcuglmbs.xyz/?code=bEadn&c=15684\' target=\'_blank\'><img src=\'https://sc.561290.xyz/sc/51mh300.gif\' width=\"300\" height=\"300\" ></a>");
break;
}

document.writeln("<table width=\"300\" border=\"0\" align=\"center\">");
document.writeln("  <tbody>");
document.writeln("    <tr>");
document.writeln("      <td width=\"141\" ><ul>");
document.writeln("        <li><a rel=\"external nofollow\" href=\"https://f164.nacebtod.xyz/aff-4Q5w\" target=\"_blank\" ><strong>YouTube成人版</strong></a></li>");
document.writeln("      </ul></td>");
document.writeln("      <td width=\"141\"><ul>");
document.writeln("        <li><a rel=\"nofollow\" href=\"https://16cd.jtalvee.xyz/chan/jm0272/33BF\" target=\"_blank\"><strong>禁漫天堂</strong></a></li>");
document.writeln("      </ul></td>");
document.writeln("    </tr>");
document.writeln("    <tr>");
document.writeln("      <td><ul>");
document.writeln("        <li><a rel=\"external nofollow\" href=\"https://04c.osooqxz.xyz/aff-DXkC\" target=\"_blank\" ><strong>园区淫乱</strong></a></li>");
document.writeln("      </ul></td>");
document.writeln("      <td><ul>");
document.writeln("        <li><a rel=\"nofollow\" href=\"https://5fb5.pcuglmbs.xyz/?code=bEadn&c=15684\" target=\"_blank\"><strong>肉漫屋</strong></a></li>");
document.writeln("      </ul></td>");
document.writeln("    </tr>");
document.writeln("    <tr>");
document.writeln("      <td><ul>");
document.writeln("        <li><a rel=\"nofollow\" href=\"https://8f0.mpnnxxic.xyz/?code=areM5&c=15684\" target=\"_blank\"><strong>肉漫屋</strong></a></li>");
document.writeln("      </ul></td>");
document.writeln("      <td><ul>");
document.writeln("        <li><a rel=\"nofollow\" href=\"https://8f0.mpnnxxic.xyz/?code=areM5&c=15684\" target=\"_blank\"><strong>成人H漫</strong></a></li>");
document.writeln("      </ul></td>");
document.writeln("    </tr>");
document.writeln("  </tbody>");
document.writeln("</table>");
document.writeln("");
