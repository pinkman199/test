var m = 2;
var n = Math.floor(Math.random() * m + 1);
switch (n) {
case 1:
document.writeln("<a href=\'https://1b2.ylhklcn.xyz/aff-dJqWb\' target=\'_blank\'><img src=\'https://sc.561290.xyz/sc/hj.gif\' width=\"300\" height=\"100\" ></a>");
break;
case 2:
document.writeln("<a href=\'https://189d.gjwiddi.xyz/chan/jm0272/33BF\' target=\'_blank\'><img src=\'https://sc.561290.xyz/sc/jm.gif\' width=\"300\" height=\"100\" ></a>");
break;


}
