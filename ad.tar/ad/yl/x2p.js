document.writeln("<table width=\"100%\" height=\"100\" bgcolor=\"#F9F9F9\">");
document.writeln("<tbody>");
document.writeln("<tr align=\"center\">");
document.writeln("<td>");
document.writeln("<div class=\"public_col_4\">");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #6399ff\" href=\"https://16cd.jtalvee.xyz/chan/jm0272/33BF\" target=\"_blank\">禁漫天堂</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #6399ff\" href=\"https://31a.pfkjqfoa.xyz/aff-Cgfs\" target=\"_blank\">7色小说</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #ff6600\" href=\"https://8f0.mpnnxxic.xyz/?code=areM5&c=15684\" target=\"_blank\">色色漫画</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #ff6600\" href=\"https://c77.zsgsrzh.xyz/chan/GS2911/csKWG\" target=\"_blank\">TikTok成人版</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #ff6600\" href=\"https://90281.skbnkyf.xyz/chan/max0613/ECKd\" target=\"_blank\">抖音Max</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #ff6600\" href=\"https://45b.pzayhqb.xyz/aff-dJqWb\" target=\"_blank\">海角乱伦社区</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #ff6600\" href=\"https://bba9.oregvso.xyz/aff-eEDKV\" target=\"_blank\">91重口</a>");
document.writeln("<a rel=\"nofollow\" class=\"bgfff\" style=\"color: #6399ff\" href=\"https://5fb5.pcuglmbs.xyz/?code=bEadn&c=15684\" target=\"_blank\">51动漫</a>");
document.writeln("</div>");
document.writeln("<style type=\"text/css\">.public_col_4 {    position: relative;    overflow: hidden;}.public_col_4 a {    width: 50%;}.public_col_4 a {    display: block;    line-height: 20px;    height: 40px;    padding: 10px;    border-right: 1px solid #e8e8e8;    border-bottom: 1px solid #e8e8e8;    text-align: center;    float: left;    background: #f8f8f8;    color: #000;    -webkit-box-sizing: border-box;    -moz-box-sizing: border-box;    box-sizing: border-box;    overflow: hidden;    white-space: nowrap;    -o-text-overflow: ellipsis;    text-overflow: ellipsis;}.bgfff {    background-color: #fff!important;}</style>");
document.writeln("</td>");
document.writeln("</tr>");
document.writeln("</tbody>");
document.writeln("</table>");

var m = 3;
var n = Math.floor(Math.random() * m + 1);
switch (n) {
case 1:
document.writeln("<a href=\"https://5fb5.pcuglmbs.xyz/?code=bEadn&c=15684\" target=\"_blank\"><img src=\"https://sc.561290.xyz/sc/m/m016.GIF\"  ></a>");
break;
case 2:
document.writeln("<a href=\"https://5fb5.pcuglmbs.xyz/?code=bEadn&c=15684\" target=\"_blank\"><img src=\"https://sc.561290.xyz/sc/m/m015.GIF\"  ></a>");
break;
case 3:
document.writeln("<a href=\"https://5fb5.pcuglmbs.xyz/?code=bEadn&c=15684\" target=\"_blank\"><img src=\"https://sc.561290.xyz/sc/m/m014.GIF\"  ></a>");
break;
}
