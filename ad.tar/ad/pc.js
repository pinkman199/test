(function() {
  // 动态插入样式
  var style = document.createElement('style');
  style.innerHTML = `
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .app {
      width: 100%;
      max-width: 1200px; /* 设置最大宽度，避免过宽 */
      background: #ffffff;
      border-radius: 4px;
      display: flex;
      flex-wrap: wrap;
      justify-content: center; /* 改为 center，使内容居中 */
      margin: 0 auto; /* 水平居中 */
      padding: 10px; /* 可选：增加内边距 */
    }

    .app li {
      display: inline-block;
      width: calc(10% - 10px); /* 每个广告宽度为 10% - 10px */
      text-align: center;
      margin: 4px 5px; /* 调整为左右 5px 间距，上下 4px */
      list-style: none;
    }

    .app img {
      width: 100%;
      max-width: 100px; /* 图片最大宽度 */
      height: auto;
      border: 3px solid #c7c7c7;
      border-radius: 8px;
    }

    .app h3 {
      font-size: 12px;
      line-height: 1.3;
      color: #000;
      margin-top: 6px;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
    }

    @media screen and (max-width: 768px) {
      .app li {
        width: calc(20% - 10px); /* 屏幕较小时显示 5 个 */
      }

      .app img {
        max-width: 80px;
      }
    }

    @media screen and (max-width: 480px) {
      .app li {
        width: calc(33.33% - 10px); /* 小屏幕下显示 3 个 */
      }

      .app img {
        max-width: 60px;
      }
    }
  `;
  document.head.appendChild(style);

  // 动态插入广告内容
  var randoms = {
    ads_codes: ['<li><a href="https://76b.adhamhe.com/aff-ca7J3" rel="external nofollow noopener" target="_blank"><div><img src="https://17357770.xyz/tu/qiyou.png"></div><h3>91妻友</h3></a></li> <li><a href="https://2aaca.wghigfe.com/aff-yqG83" rel="external nofollow noopener" target="_blank"><div><img src="https://17357770.xyz/tu/51chigua.jpeg"></div><h3>51吃瓜</h3></a></li><li><a href="https://5529f.ddrlchju.org/aff-dJqWb" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/haijiao.jpg"></div><h3>海角乱伦</h3></a></li><li><a href="https://9224.txuypbg.org/aff-dyNUq" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/anwang.jpg"></div><h3>暗网禁区</h3></a></li><li><a href="https://958db.lfflqdv.com/chan/h56094/5ezaH" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/50.jpg"></div><h3>重口50度灰</h3></a></li><li><a href="https://d62.vwygohka.com/chan/GS1228/a4sGP" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/luoli.gif"></div><h3>51萝莉</h3></a></li><li><a href="https://d62.vwygohka.com/chan/GS1228/a4sGP" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/rou.gif"></div><h3>51动漫</h3></a></li><li><a href="https://359e8.tbgaiksb.org/chan/GS2911/csKWG" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/dy1214.png"></div><h3>Tiktok成人版</h3></a></li><li><a href="https://064b6.zljyrfnk.org/chan/jm0272/33BF" rel="external nofollow noopener" target="_blank"><div><img src="https://go.xiaoshuogo.cc/tu/xingai.jpg"></div><h3>禁漫天堂</h3></a></li><li><a href="https://cf8aa.dzfvmre.com/c-15684/a-bSvvF" rel="external nofollow noopener" target="_blank"><div><img src="https://17357770.xyz/tu/mayi.png"></div><h3>蚂蚁翻墙</h3></a></li>'],
    ads_weight: [10],

    get_random: function(weight) {
      var s = eval(weight.join('+'));
      var r = Math.floor(Math.random() * s);
      var w = 0;
      var n = weight.length - 1;
      for (var k in weight) {
        w += weight[k];
        if (w >= r) {
          n = k;
          break;
        }
      }
      return n;
    },
    init: function() {
      var rand = this.get_random(this.ads_weight);
      var adsContainer = document.createElement('div');
      adsContainer.className = 'app';
      var ul = document.createElement('ul');
      ul.innerHTML = this.ads_codes[rand];
      adsContainer.appendChild(ul);
      document.body.appendChild(adsContainer);
    }
  };

  randoms.init(); // 初始化并展示广告
})();
