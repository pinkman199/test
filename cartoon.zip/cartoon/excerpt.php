<?php if ( has_post_format( 'gallery' )) {  ?>
<!-- 如果文章类型是「相册格式」，则执行这里。 -->
<div class="post_gallery post_loop">
    <div class="post_gallery_head">
    <h2><a class="stretched-link" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
    <?php
    $i = 3;
    $attachments = get_attached_media( 'image', $post->ID );
    if ($attachments) { ?>
    <div class="row row-cols-4 g-3 mb-3">
    <?php $count = 0; foreach ( $attachments as $value) { ?>
        <div class="col">
            <?php echo wp_get_attachment_image($value->ID, array(400, 240, true)); ?>
        </div>
    <?php if( $count == $i ) break; $count++; } ?>
    </div>
    <?php } ?>
    </div>
    <div class="post_info">
        <div class="post_info_l">
            <span><i class="bi bi-text-left"></i><?php the_category(', ') ?></span>
            <span class="mobile_none"><i class="bi bi-clock"></i><?php the_time('Y.m.d'); ?></span>
            <span class=""><i class="bi bi-eye"></i><?php post_views('',''); ?>人浏览</span>
        </div>
        <div class="post_info_r">
            <?php the_tags( '<em><i class="bi bi-hash"></i>', '</em><em><i class="bi bi-hash"></i>', '</em>' ); ?>
        </div>
    </div>
</div>

<?php } else if  ( has_post_format( 'image' )) {  ?>
<!-- 如果文章是「图片格式」，执行这里。 -->
<div class="post_images post_loop">
    <?php
    if ( has_post_thumbnail() ) {
        the_post_thumbnail(array(920, 400, true));
    } else {
        echo wp_get_attachment_image(get_theme_mod('ds_nopic'), array(920, 400, true));
    }
    ?>
    <div class="post_images_foot">
        <h2><a class="stretched-link" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
        <p><?php echo wp_trim_words( get_the_content(), 150 ); ?></p>
        <div class="post_info">
            <div class="post_info_l">
                <span><i class="bi bi-text-left"></i><?php the_category(', ') ?></span>
                <span><i class="bi bi-clock"></i><?php the_time('Y.m.d'); ?></span>
                <span><i class="bi bi-eye"></i><?php post_views('',''); ?>人浏览</span>
            </div>
        </div>
    </div>
</div>

<?php } else { // 改为纯卡片式，无摘要 ?>
<div class="post_card col-6 col-sm-6 col-md-4 mb-4">

  <div class="card h-100 shadow-sm border-0 overflow-hidden">
    <a href="<?php the_permalink(); ?>" class="card-img-top d-block position-relative">
      <?php
      if ( has_post_thumbnail() ) {
          // 直接指定像素尺寸裁剪，宽高可改成你希望的卡片尺寸
          the_post_thumbnail(array(600, 800, true), ['class' => 'img-fluid rounded-top w-100']);
      } else {
          echo wp_get_attachment_image(get_theme_mod('ds_nopic'), array(600, 400, true), false, ['class' => 'img-fluid rounded-top w-100']);
      }
      ?>
    </a>
    <div class="card-body p-3">
      <h5 class="card-title mb-0 text-center">
        <a href="<?php the_permalink(); ?>" class="text-dark text-decoration-none">
          <?php the_title(); ?>
        </a>
      </h5>
    </div>
    <div class="card-footer bg-white border-0 small text-muted d-flex justify-content-between px-3 pb-3">
      <span><i class="bi bi-text-left"></i> <?php the_category(', ') ?></span>
      <span><i class="bi bi-clock"></i> <?php the_time('Y.m.d'); ?></span>
    </div>
  </div>
</div>
<?php } ?>
